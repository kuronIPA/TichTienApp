# TichTienApp

App iOS SwiftUI đơn giản để cộng tiền.

## Tính năng
- Hiển thị tổng tiền hiện tại.
- Nút +5.000đ, +10.000đ, +15.000đ, +20.000đ, +50.000đ.
- Tự lưu số dư bằng UserDefaults.
- Nút Đặt lại.

## Build
Mở `TichTienApp.xcodeproj` bằng Xcode trên Mac, chọn iPhone của bạn, đặt Signing Team trong target `TichTienApp`, rồi Build/Archive.

Để tạo IPA: Xcode > Product > Archive > Distribute App > Development (hoặc Ad Hoc/TestFlight tùy cách phân phối).
