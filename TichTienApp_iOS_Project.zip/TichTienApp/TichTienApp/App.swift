import SwiftUI

@main
struct TichTienApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
