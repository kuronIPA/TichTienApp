import SwiftUI

struct ContentView: View {
    @AppStorage("totalAmount") private var totalAmount: Int = 0

    private let amounts = [5_000, 10_000, 15_000, 20_000, 50_000]

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                VStack(spacing: 8) {
                    Text("SỐ DƯ")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)

                    Text(formatVND(totalAmount))
                        .font(.system(size: 42, weight: .bold, design: .rounded))
                        .contentTransition(.numericText())
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 28)
                .background(
                    RoundedRectangle(cornerRadius: 24)
                        .fill(Color(.secondarySystemBackground))
                )

                VStack(spacing: 12) {
                    ForEach(amounts, id: \.self) { amount in
                        Button {
                            withAnimation(.snappy) {
                                totalAmount += amount
                            }
                        } label: {
                            Text("+ " + formatVND(amount))
                                .font(.title3.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                Button(role: .destructive) {
                    totalAmount = 0
                } label: {
                    Label("Đặt lại", systemImage: "arrow.counterclockwise")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .padding(.top, 4)

                Spacer()
            }
            .padding()
            .navigationTitle("Tích tiền")
        }
    }

    private func formatVND(_ value: Int) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.groupingSeparator = "."
        formatter.locale = Locale(identifier: "vi_VN")
        return (formatter.string(from: NSNumber(value: value)) ?? "0") + "đ"
    }
}

#Preview {
    ContentView()
}
